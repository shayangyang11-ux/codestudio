<template>
  <main class="app-shell">
    <aside class="app-sidebar">
      <strong>CodeMind Generated App</strong>
      <span>Node.js Fullstack</span>
    </aside>
    <section class="app-content">
      <component :is="activePage" />
    </section>
  </main>
</template>

<script setup>
import { computed } from 'vue'
import { generatedRoutes } from './router/routes.js'

const activePage = computed(() => {
  const pathname = window.location.pathname || '/'
  return generatedRoutes.find((route) => route.path === pathname)?.component || generatedRoutes[0]?.component
})
</script>
