async function main() {
  const health = await fetch('http://127.0.0.1:3101/api/health')
  assert(health.ok, 'health endpoint should be ok')
  console.log('Smoke test passed.')
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}

main().catch((error) => {
  console.error(error)
  process.exit(1)
})
