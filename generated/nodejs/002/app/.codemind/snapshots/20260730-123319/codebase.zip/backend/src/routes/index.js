import { readStore, writeStore } from '../db/localStore.js'
import { sendOk } from '../shared/response.js'

export function registerGeneratedRoutes(app) {
  app.get('/api/:moduleKey', async (req, res, next) => {
    try {
      const store = await readStore()
      const bucket = ensureBucket(store, req.params.moduleKey)
      sendOk(res, bucket)
    } catch (error) {
      next(error)
    }
  })

  app.post('/api/:moduleKey', async (req, res, next) => {
    try {
      const store = await readStore()
      const bucket = ensureBucket(store, req.params.moduleKey)
      const nextRecord = {
        id: `${normalizeKey(req.params.moduleKey)}-${Date.now()}`,
        ...(req.body || {}),
        status: req.body?.status || 'ACTIVE',
        createdAt: new Date().toISOString(),
      }

      bucket.push(nextRecord)
      await writeStore(store)
      sendOk(res, nextRecord)
    } catch (error) {
      next(error)
    }
  })

  app.post('/api/:moduleKey/actions/:actionKey', async (req, res, next) => {
    try {
      const store = await readStore()
      const bucket = ensureBucket(store, req.params.moduleKey)
      const actionRecord = {
        id: `${normalizeKey(req.params.actionKey)}-${Date.now()}`,
        action: req.params.actionKey,
        ...(req.body || {}),
        status: 'DONE',
        createdAt: new Date().toISOString(),
      }

      bucket.push(actionRecord)
      await writeStore(store)
      sendOk(res, actionRecord, { action: req.params.actionKey })
    } catch (error) {
      next(error)
    }
  })
}

function ensureBucket(store, moduleKey) {
  const bucketKey = normalizeKey(moduleKey)

  if (!Array.isArray(store[bucketKey])) {
    store[bucketKey] = []
  }

  return store[bucketKey]
}

function normalizeKey(value) {
  return String(value || 'records').replace(/[^a-zA-Z0-9_]/g, '_') || 'records'
}
