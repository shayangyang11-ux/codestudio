import GeneratedHomePage from '../modules/generated/pages/GeneratedHomePage.vue'

export const generatedRoutes = [
  {
    path: '/',
    name: 'GeneratedHome',
    component: GeneratedHomePage,
  },
]
