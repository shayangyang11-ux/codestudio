export const seedData = {
  records: [
    {
      id: 'demo-001',
      title: '初始化演示记录',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    },
  ],
}
