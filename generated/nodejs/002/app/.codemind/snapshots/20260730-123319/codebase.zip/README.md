# CodeMind Node.js 全栈生成项目

本目录是 Dev Agent 生成的 Node.js 全栈代码主干。所有模块树节点的代码贡献都会进入同一个 app，而不是为每个节点生成孤立项目。

## 运行方式

```powershell
npm install
npm run dev
npm run build
npm test
```

默认地址：

- 前端：http://127.0.0.1:5178
- 后端：http://127.0.0.1:3101
- 健康检查：http://127.0.0.1:3101/api/health

## 当前贡献

当前节点：认证模块
当前页面/场景：认证模块

认证模块提供用户身份认证能力，包括登录、注册、退出登录，确保系统访问安全。

### 功能清单

- **用户注册**：未注册用户通过注册页填写账号、昵称、密码和确认密码，提交后系统创建新用户账号
- **用户登录**：已注册用户通过登录页输入账号和密码，系统验证身份后建立登录会话
- **退出登录**：已登录用户点击退出登录按钮，系统清除当前会话并跳转到登录页

### 页面清单

- **登录页**（/auth/login）：用户输入账号密码进行登录的页面
- **注册页**（/auth/register）：用户填写注册信息进行注册的页面

## 代码映射

`codemind.generated.json` 记录模块树节点与代码文件的映射关系。平台会基于它实现：

- 按项目目录查看完整代码
- 按模块树节点查看相关代码
- 定位页面或功能场景预览入口
- 判断代码是否需要重新生成

## 目录结构

```
app/
├── frontend/          # Vite + Vue 前端工程
│   ├── src/
│   │   ├── pages/     # 页面组件
│   │   ├── components/# 共享组件
│   │   ├── api/       # API 调用层
│   │   └── router/    # 路由配置
│   └── package.json
├── backend/           # Express 后端工程
│   ├── src/
│   │   ├── routes/    # 路由定义
│   │   ├── controllers/# 控制器
│   │   ├── services/  # 业务逻辑
│   │   ├── models/    # 数据模型
│   │   └── middleware/# 中间件
│   └── package.json
├── tests/             # 测试文件
└── package.json       # 根配置
```
