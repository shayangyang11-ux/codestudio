import GeneratedHomePage from '../modules/generated/pages/GeneratedHomePage.vue'

// 入库单管理模块路由
const inboundOrderRoutes = [
  {
    path: '/inbound/orders',
    name: 'InboundOrderList',
    component: () => import('../modules/inbound-order/pages/InboundOrderListPage.vue'),
    meta: {
      title: '入库单列表页',
      pageKey: 'inbound_order_list_page',
      moduleId: 'inbound_order_management'
    }
  },
  {
    path: '/inbound/orders/create',
    name: 'InboundOrderCreate',
    component: () => import('../modules/inbound-order/pages/InboundOrderCreatePage.vue'),
    meta: {
      title: '入库单创建页',
      pageKey: 'inbound_order_create_page',
      moduleId: 'inbound_order_management'
    }
  },
  {
    path: '/inbound/orders/:id/approval',
    name: 'InboundOrderApproval',
    component: () => import('../modules/inbound-order/pages/InboundOrderApprovalPage.vue'),
    meta: {
      title: '入库单审核页',
      pageKey: 'inbound_order_approval_page',
      moduleId: 'inbound_order_management'
    }
  },
  {
    path: '/inbound/orders/:id/quantity-edit',
    name: 'InboundOrderQuantityEdit',
    component: () => import('../modules/inbound-order/pages/InboundOrderQuantityEditPage.vue'),
    meta: {
      title: '入库单数量编辑页',
      pageKey: 'inbound_order_quantity_edit_page',
      moduleId: 'inbound_order_management'
    }
  },
  {
    path: '/inbound/orders/:id',
    name: 'InboundOrderDetail',
    component: () => import('../modules/inbound-order/pages/InboundOrderDetailPage.vue'),
    meta: {
      title: '入库单详情页',
      pageKey: 'inbound_order_detail_page',
      moduleId: 'inbound_order_management'
    }
  }
]

// 生成的路由
export const generatedRoutes = [
  {
    path: '/',
    name: 'GeneratedHome',
    component: GeneratedHomePage,
  },
  ...inboundOrderRoutes
]

// 导出模块路由供其他模块使用
export { inboundOrderRoutes }

export default generatedRoutes
