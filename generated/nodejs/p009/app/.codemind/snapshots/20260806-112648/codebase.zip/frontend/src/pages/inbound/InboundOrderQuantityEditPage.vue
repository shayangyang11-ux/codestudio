<template>
  <section class="generated-page">
    <header class="generated-page__header">
      <p class="generated-page__eyebrow">Generated Node.js Page</p>
      <h1>入库单数量编辑页</h1>
      <span>该页面由 Development Agent 生成，用于真实 Node.js 系统运行预览。</span>
    </header>

    <section class="generated-page__card">
      <h2>入库单数量编辑页</h2>
      <p>页面文件已补齐，后续会继续接入真实表单、列表、接口和数据逻辑。</p>
    </section>
  </section>
</template>

<script setup>
</script>

<style scoped>
.generated-page {
  min-height: 100vh;
  padding: 32px;
  background: #f5f7fb;
  color: #0f172a;
}

.generated-page__header,
.generated-page__card {
  background: #fff;
  border: 1px solid #dbe4f0;
  border-radius: 18px;
  padding: 24px;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.06);
}

.generated-page__header {
  margin-bottom: 20px;
}

.generated-page__eyebrow {
  margin: 0 0 8px;
  color: #2563eb;
  font-size: 12px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

h1, h2 {
  margin: 0 0 10px;
}

span, p {
  color: #475569;
}
</style>
