<template>
  <section class="generated-page">
    <header class="generated-page__header">
      <p class="generated-page__eyebrow">Generated Node.js Page</p>
      <h1>InboundOrderApprovalPage</h1>
      <span>该页面由 Development Agent 生成，用于真实 Node.js 系统运行预览。</span>
    </header>

    <section class="generated-page__card">
      <h2>InboundOrderApprovalPage</h2>
      <p>页面文件已补齐。后续应由 Development Agent 接入真实表单、列表、接口、数据和权限逻辑。</p>
      <div class="generated-page__actions">
        <button type="button">新增</button>
        <button type="button">查询</button>
        <button type="button">保存</button>
      </div>
    </section>
  </section>
</template>

<script setup>
</script>

<style scoped>
.generated-page {
  min-height: 100vh;
  padding: 32px;
  background: #f5f7fb;
  color: #0f172a;
}

.generated-page__header,
.generated-page__card {
  background: #fff;
  border: 1px solid #dbe4f0;
  border-radius: 18px;
  padding: 24px;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.06);
}

.generated-page__header {
  margin-bottom: 20px;
}

.generated-page__eyebrow {
  margin: 0 0 8px;
  color: #2563eb;
  font-size: 12px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

.generated-page__actions {
  display: flex;
  gap: 10px;
  margin-top: 18px;
}

.generated-page__actions button {
  border: 1px solid #bfdbfe;
  background: #eff6ff;
  color: #1d4ed8;
  border-radius: 999px;
  padding: 8px 14px;
  font-weight: 700;
}

h1, h2 {
  margin: 0 0 10px;
}

span, p {
  color: #475569;
}
</style>
