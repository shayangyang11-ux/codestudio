/**
 * 入库单管理模块
 * 模块Key: inbound_order_management
 * 模块路由前缀: /inbound/orders
 */

export const moduleMeta = {
  key: 'inbound-order-management',
  title: '入库单管理',
  description: '管理入库单的创建、查询、审核和详情查看',
  icon: 'inbox',
  order: 100
};

/**
 * 模块路由配置
 */
export const moduleRoutes = [
  {
    path: '/inbound/orders',
    name: 'InboundOrderList',
    component: () => import('./pages/InboundOrderListPage.vue'),
    meta: {
      title: '入库单列表',
      requiresAuth: true,
      pageKey: 'inbound_order_list_page'
    }
  },
  {
    path: '/inbound/orders/create',
    name: 'InboundOrderCreate',
    component: () => import('./pages/InboundOrderCreatePage.vue'),
    meta: {
      title: '创建入库单',
      requiresAuth: true,
      pageKey: 'inbound_order_create_page'
    }
  },
  {
    path: '/inbound/orders/:id',
    name: 'InboundOrderDetail',
    component: () => import('./pages/InboundOrderDetailPage.vue'),
    meta: {
      title: '入库单详情',
      requiresAuth: true,
      pageKey: 'inbound_order_detail_page'
    }
  },
  {
    path: '/inbound/orders/:id/edit',
    name: 'InboundOrderEdit',
    component: () => import('./pages/InboundOrderEditPage.vue'),
    meta: {
      title: '编辑入库单',
      requiresAuth: true,
      pageKey: 'inbound_order_edit_page'
    }
  },
  {
    path: '/inbound/orders/:id/approve',
    name: 'InboundOrderApprove',
    component: () => import('./pages/InboundOrderApprovePage.vue'),
    meta: {
      title: '审核入库单',
      requiresAuth: true,
      pageKey: 'inbound_order_approve_page'
    }
  }
];

/**
 * 模块页面组件映射
 */
export const modulePages = {
  inbound_order_list_page: 'InboundOrderListPage',
  inbound_order_create_page: 'InboundOrderCreatePage',
  inbound_order_detail_page: 'InboundOrderDetailPage',
  inbound_order_edit_page: 'InboundOrderEditPage',
  inbound_order_approve_page: 'InboundOrderApprovePage'
};

/**
 * 模块安装函数
 * @param {Object} app - Vue应用实例
 * @param {Object} router - Vue Router实例
 */
export function installModule(app, router) {
  // 注册模块路由
  moduleRoutes.forEach(route => {
    router.addRoute(route);
  });

  // 注册模块全局组件（如有）
  // app.component('InboundOrderStatusTag', InboundOrderStatusTag);
}

/**
 * 获取模块菜单配置
 */
export function getMenuConfig() {
  return {
    key: 'inbound-order-management',
    title: '入库单管理',
    icon: 'inbox',
    children: [
      {
        key: 'inbound-order-list',
        title: '入库单列表',
        path: '/inbound/orders',
        icon: 'list'
      },
      {
        key: 'inbound-order-create',
        title: '创建入库单',
        path: '/inbound/orders/create',
        icon: 'plus'
      }
    ]
  };
}

export default {
  moduleMeta,
  moduleRoutes,
  modulePages,
  installModule,
  getMenuConfig
};
