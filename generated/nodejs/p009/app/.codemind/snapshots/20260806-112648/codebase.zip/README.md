# CodeMind Node.js 全栈生成项目

本目录是 Dev Agent 生成的 Node.js 全栈代码主干。所有模块树节点的代码贡献都会进入同一个 app，而不是为每个节点生成孤立项目。

## 运行方式

```powershell
npm install
npm run dev
npm run build
npm test
```

默认地址：

- 前端：http://127.0.0.1:5178
- 后端：http://127.0.0.1:3101
- 健康检查：http://127.0.0.1:3101/api/health

## 当前贡献

当前节点：入库单管理
当前页面/场景：入库单管理

入库单列表页交互原型 / UI_CONTRACT 1. 页面定位 Page ID： a44d763d 16e3 429f 9e14 870c2b8e496d Page Key： inbound_order_list_page Route： /inbound/orders Page Kind： LIS

## 代码映射

`codemind.generated.json` 记录模块树节点与代码文件的映射关系。平台会基于它实现：

- 按项目目录查看完整代码
- 按模块树节点查看相关代码
- 定位页面或功能场景预览入口
- 判断代码是否需要重新生成
