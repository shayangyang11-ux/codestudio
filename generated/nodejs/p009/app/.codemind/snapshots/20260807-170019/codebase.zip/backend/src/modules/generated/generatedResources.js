export const generatedResources = [
  {
    "resourceKey": "inbound_order_list_page",
    "apiSegment": "inbound-orders",
    "title": "入库单列表页",
    "pageKey": "inbound_order_list_page",
    "routePath": "/inbound/orders",
    "description": "由 Development Build Context 生成的业务资源。",
    "pageKind": "GENERIC",
    "surfaceType": "MAIN_NAV_PAGE",
    "navigationVisible": true,
    "entryMode": "NAVIGATION",
    "fields": [
      {
        "key": "id",
        "label": "ID",
        "type": "TEXT",
        "required": false
      }
    ],
    "seedRecords": [
      {
        "id": "inbound_order_list_page-001",
        "createdAt": "2026-08-11 09:30:00"
      },
      {
        "id": "inbound_order_list_page-002",
        "createdAt": "2026-08-12 09:30:00"
      },
      {
        "id": "inbound_order_list_page-003",
        "createdAt": "2026-08-13 09:30:00"
      }
    ]
  },
  {
    "resourceKey": "inbound_order_create_page",
    "apiSegment": "inbound-orders-2",
    "title": "入库单创建页",
    "pageKey": "inbound_order_create_page",
    "routePath": "/inbound/orders/create",
    "description": "由 Development Build Context 生成的业务资源。",
    "pageKind": "GENERIC",
    "surfaceType": "ACTION_ROUTE_PAGE",
    "navigationVisible": false,
    "entryMode": "ACTION_ROUTE",
    "fields": [
      {
        "key": "id",
        "label": "ID",
        "type": "TEXT",
        "required": false
      }
    ],
    "seedRecords": [
      {
        "id": "inbound_order_create_page-001",
        "createdAt": "2026-08-11 09:30:00"
      },
      {
        "id": "inbound_order_create_page-002",
        "createdAt": "2026-08-12 09:30:00"
      },
      {
        "id": "inbound_order_create_page-003",
        "createdAt": "2026-08-13 09:30:00"
      }
    ]
  },
  {
    "resourceKey": "inbound_order_approval_page",
    "apiSegment": "inbound-orders-3",
    "title": "入库单审核页",
    "pageKey": "inbound_order_approval_page",
    "routePath": "/inbound/orders/approval",
    "description": "由 Development Build Context 生成的业务资源。",
    "pageKind": "GENERIC",
    "surfaceType": "ACTION_ROUTE_PAGE",
    "navigationVisible": false,
    "entryMode": "ACTION_ROUTE",
    "fields": [
      {
        "key": "id",
        "label": "ID",
        "type": "TEXT",
        "required": false
      }
    ],
    "seedRecords": [
      {
        "id": "inbound_order_approval_page-001",
        "createdAt": "2026-08-11 09:30:00"
      },
      {
        "id": "inbound_order_approval_page-002",
        "createdAt": "2026-08-12 09:30:00"
      },
      {
        "id": "inbound_order_approval_page-003",
        "createdAt": "2026-08-13 09:30:00"
      }
    ]
  },
  {
    "resourceKey": "inbound_order_quantity_edit_page",
    "apiSegment": "inbound-orders-4",
    "title": "入库单数量编辑页",
    "pageKey": "inbound_order_quantity_edit_page",
    "routePath": "/inbound/orders/quantity-edit",
    "description": "由 Development Build Context 生成的业务资源。",
    "pageKind": "GENERIC",
    "surfaceType": "ACTION_ROUTE_PAGE",
    "navigationVisible": false,
    "entryMode": "ACTION_ROUTE",
    "fields": [
      {
        "key": "id",
        "label": "ID",
        "type": "TEXT",
        "required": false
      }
    ],
    "seedRecords": [
      {
        "id": "inbound_order_quantity_edit_page-001",
        "createdAt": "2026-08-11 09:30:00"
      },
      {
        "id": "inbound_order_quantity_edit_page-002",
        "createdAt": "2026-08-12 09:30:00"
      },
      {
        "id": "inbound_order_quantity_edit_page-003",
        "createdAt": "2026-08-13 09:30:00"
      }
    ]
  },
  {
    "resourceKey": "inbound_order_detail_page",
    "apiSegment": "inbound-orders-5",
    "title": "入库单详情页",
    "pageKey": "inbound_order_detail_page",
    "routePath": "/inbound/orders/detail",
    "description": "由 Development Build Context 生成的业务资源。",
    "pageKind": "GENERIC",
    "surfaceType": "ACTION_ROUTE_PAGE",
    "navigationVisible": false,
    "entryMode": "ACTION_ROUTE",
    "fields": [
      {
        "key": "id",
        "label": "ID",
        "type": "TEXT",
        "required": false
      }
    ],
    "seedRecords": [
      {
        "id": "inbound_order_detail_page-001",
        "createdAt": "2026-08-11 09:30:00"
      },
      {
        "id": "inbound_order_detail_page-002",
        "createdAt": "2026-08-12 09:30:00"
      },
      {
        "id": "inbound_order_detail_page-003",
        "createdAt": "2026-08-13 09:30:00"
      }
    ]
  }
]
