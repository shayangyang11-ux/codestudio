<template>
  <main :class="['app-shell', shellClass]">
    <aside v-if="isSidebar" class="app-sidebar">
      <strong>{{ appShell.title }}</strong>
      <span>{{ shellSubtitle }}</span>
      <nav v-if="navigationRoutes.length">
        <button
          v-for="route in navigationRoutes"
          :key="route.path"
          type="button"
          :class="{ active: currentPath === route.path }"
          @click="go(route.path)"
        >
          {{ route.meta?.title || route.title || route.name }}
        </button>
      </nav>
      <p v-else class="shell-hint">该模块没有固定导航，请通过页面动作流转。</p>
    </aside>

    <section class="app-main">
      <header v-if="isTopNav" class="app-topbar">
        <div>
          <strong>{{ appShell.title }}</strong>
          <span>{{ shellSubtitle }}</span>
        </div>
        <nav v-if="navigationRoutes.length">
          <button
            v-for="route in navigationRoutes"
            :key="route.path"
            type="button"
            :class="{ active: currentPath === route.path }"
            @click="go(route.path)"
          >
            {{ route.meta?.title || route.title || route.name }}
          </button>
        </nav>
      </header>

      <header v-if="isActionHub" class="app-action-hub">
        <div>
          <small>MODULE ACTION FLOW</small>
          <h1>{{ appShell.title }}</h1>
          <p>当前模块使用按钮和业务动作串联页面，没有强制固定导航栏。</p>
        </div>
      </header>

      <section v-if="currentActions.length" class="module-action-bar">
        <div>
          <small>页面动作</small>
          <strong>{{ currentRouteTitle }}</strong>
        </div>
        <div class="module-action-buttons">
          <button
            v-for="edge in currentActions"
            :key="edge.actionId + ':' + edge.targetRoute"
            type="button"
            @click="go(edge.targetRoute)"
          >
            {{ edge.actionLabel || edge.label || edge.targetPageName || '打开页面' }}
          </button>
        </div>
      </section>

      <section class="app-content">
        <RouterView />
      </section>
    </section>
  </main>
</template>

<script setup>
import { computed } from 'vue'
import { RouterView, useRoute, useRouter } from 'vue-router'
import { navigationRoutes } from './router/routes.js'

const appShell = {
  "layout": "SIDEBAR",
  "navigationPlacement": "left",
  "shellKind": "ADMIN_SIDEBAR",
  "title": "入库单管理",
  "defaultPageKey": "inbound_order_list_page",
  "defaultRoute": "/inbound/orders",
  "navigation": [
    {
      "label": "入库单列表页",
      "pageKey": "inbound_order_list_page",
      "route": "/inbound/orders",
      "visible": true,
      "surfaceType": "MAIN_NAV_PAGE"
    }
  ],
  "style": {
    "navTheme": "dark",
    "density": "business"
  }
}
const navigationEdges = [
  {
    "sourcePageKey": "inbound_order_list_page",
    "sourcePageName": "入库单列表页",
    "sourceRoute": "/inbound/orders",
    "actionId": "create",
    "actionLabel": "新建",
    "label": "新建",
    "interactionType": "ROUTE_NAVIGATION",
    "targetPageKey": "inbound_order_create_page",
    "targetPageName": "入库单创建页",
    "targetRoute": "/inbound/orders/create",
    "renderAs": "ACTION_BUTTON"
  },
  {
    "sourcePageKey": "inbound_order_list_page",
    "sourcePageName": "入库单列表页",
    "sourceRoute": "/inbound/orders",
    "actionId": "approval",
    "actionLabel": "审核",
    "label": "审核",
    "interactionType": "ROUTE_NAVIGATION",
    "targetPageKey": "inbound_order_approval_page",
    "targetPageName": "入库单审核页",
    "targetRoute": "/inbound/orders/approval",
    "renderAs": "ACTION_BUTTON"
  },
  {
    "sourcePageKey": "inbound_order_list_page",
    "sourcePageName": "入库单列表页",
    "sourceRoute": "/inbound/orders",
    "actionId": "edit",
    "actionLabel": "编辑",
    "label": "编辑",
    "interactionType": "ROUTE_NAVIGATION",
    "targetPageKey": "inbound_order_quantity_edit_page",
    "targetPageName": "入库单数量编辑页",
    "targetRoute": "/inbound/orders/quantity-edit",
    "renderAs": "ACTION_BUTTON"
  },
  {
    "sourcePageKey": "inbound_order_list_page",
    "sourcePageName": "入库单列表页",
    "sourceRoute": "/inbound/orders",
    "actionId": "detail",
    "actionLabel": "查看详情",
    "label": "查看详情",
    "interactionType": "ROUTE_NAVIGATION",
    "targetPageKey": "inbound_order_detail_page",
    "targetPageName": "入库单详情页",
    "targetRoute": "/inbound/orders/detail",
    "renderAs": "ACTION_BUTTON"
  }
]

const route = useRoute()
const router = useRouter()

const currentPath = computed(() => route.path)
const currentPageKey = computed(() => String(route.meta?.pageKey || ''))
const currentRouteTitle = computed(() => String(route.meta?.title || route.title || route.name || '当前页面'))

const shellLayout = computed(() => String(appShell.layout || 'SIDEBAR').toUpperCase())
const isSidebar = computed(() => shellLayout.value === 'SIDEBAR')
const isTopNav = computed(() => shellLayout.value === 'TOP_NAV')
const isActionHub = computed(() => shellLayout.value === 'ACTION_HUB' || shellLayout.value === 'NO_NAV')
const shellClass = computed(() => `layout-${shellLayout.value.toLowerCase().replace(/_/g, '-')}`)
const shellSubtitle = computed(() => {
  if (isTopNav.value) return 'Top Navigation'
  if (isActionHub.value) return 'Action Flow'
  return 'Node.js Fullstack'
})

const currentActions = computed(() => {
  return navigationEdges.filter((edge) => {
    const sourcePageKey = String(edge.sourcePageKey || '')
    const sourceRoute = normalizeRoute(edge.sourceRoute || '')
    const targetRoute = normalizeRoute(edge.targetRoute || '')
    if (!targetRoute) return false
    return sourcePageKey === currentPageKey.value || sourceRoute === normalizeRoute(route.path)
  })
})

function normalizeRoute(value) {
  const text = String(value || '').trim()
  if (!text) return ''
  return '/' + text.replace(/^\/+|\/+$/g, '')
}

function go(path) {
  const target = normalizeRoute(path)
  if (target) router.push(target)
}
</script>
