import express from 'express'
import { generatedResources } from '../modules/generated/generatedResources.js'
import { createGeneratedResourceRouter } from '../modules/generated/generated-resource.routes.js'
import { ok, sendOk } from '../shared/response.js'

const router = express.Router()
const resourceByKey = Object.fromEntries(generatedResources.map((item) => [item.resourceKey, item]))

router.get('/health', (request, response) => {
  ok(response, {
    service: 'codemind-generated-nodejs',
    status: 'UP',
    resourceCount: generatedResources.length,
    generatedAt: new Date().toISOString(),
  })
})

for (const resource of generatedResources) {
  const segment = String(resource.apiSegment || resource.resourceKey || '').replace(/^\/+|\/+$/g, '')
  if (segment) {
    router.use('/' + segment, createGeneratedResourceRouter(resource))
  }
}

export function registerGeneratedRoutes(app) {
  app.get('/health', (request, response) => {
    sendOk(response, {
      service: 'codemind-generated-backend',
      status: 'UP',
      generatedAt: new Date().toISOString(),
    })
  })

  app.get('/api/health', (request, response) => {
    sendOk(response, {
      service: 'codemind-generated-backend',
      status: 'UP',
      generatedAt: new Date().toISOString(),
    })
  })

  app.use('/api', router)
  return app
}

export default router
