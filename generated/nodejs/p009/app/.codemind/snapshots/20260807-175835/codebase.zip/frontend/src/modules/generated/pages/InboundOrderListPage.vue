<template>
  <section class="ucg-page">
    <header class="ucg-page-header">
      <div>
        <p class="ucg-eyebrow">Confirmed UI_CONTRACT</p>
        <h1>入库单列表页</h1>
        <p>面向业务人员的入库单列表页查询、筛选和数据管理页面。</p>
      </div>
      <div class="ucg-actions">
          <button class="ucg-btn" type="button" @click="handleAction('inbound_order_list_page_query')">查询</button>
          <button class="ucg-btn" type="button" @click="handleAction('inbound_order_list_page_create')">新增</button>
          <button class="ucg-btn" type="button" @click="handleAction('inbound_order_list_page_export')">导出</button>
      </div>
    </header>

<section class="ucg-card">
      <header class="ucg-card-header">
        <div>
          <h2>查询条件</h2>
          <p>全宽筛选区，不参与卡片宫格布局。</p>
        </div>
      </header>
        <section class="ucg-card">
        <header class="ucg-card-header">
          <div>
            <h2>查询筛选</h2>
            <p>根据业务字段快速定位数据。</p>
          </div>
        </header>
          <form class="ucg-form" @submit.prevent="handleAction('submit')">
          <label class="ucg-field"><span>入库单号</span>
            <input type="text" v-model="form['inboundno']" placeholder="请输入入库单号" />
          </label>
          <label class="ucg-field"><span>供应商</span>
            <select v-model="form['supplierid']">
              <option value="">请选择</option>
            </select>
          </label>
          <label class="ucg-field"><span>仓库</span>
            <select v-model="form['warehouseid']">
              <option value="">请选择</option>
            </select>
          </label>
          <label class="ucg-field"><span>关键字</span>
            <input type="text" v-model="form['keyword']" placeholder="请输入关键字" />
          </label>
          </form>
          <div class="ucg-actions">
            <button class="ucg-btn primary" type="button" @click="handleAction('inbound_order_list_page_query')">查询</button>
            <button class="ucg-btn primary" type="button" @click="handleAction('inbound_order_list_page_reset_filters')">重置</button>
          </div>
        </section>

      </section>
      <section class="ucg-card">
      <header class="ucg-card-header">
        <div>
          <h2>数据列表</h2>
          <p>表格占满内容区，工具栏和表格保持同一业务区域。</p>
        </div>
      </header>
        <section class="ucg-card">
        <header class="ucg-card-header"><div></div></header>
          <p>内容区</p>
          <div class="ucg-actions">
            <button class="ucg-btn primary" type="button" @click="handleAction('inbound_order_list_page_create')">新增</button>
            <button class="ucg-btn primary" type="button" @click="handleAction('inbound_order_list_page_export')">导出</button>
          </div>
        </section>
        <section class="ucg-card">
        <header class="ucg-card-header">
          <div>
            <h2>数据列表</h2>
            <p>展示筛选后的业务数据，支持分页与行级操作。</p>
          </div>
        </header>
          <div class="ucg-table-wrap">
            <table class="ucg-table">
              <thead>
              <tr>
                <th>入库单号</th>
                <th>供应商</th>
                <th>仓库</th>
                <th>入库状态</th>
                <th>经办人</th>
                <th>创建时间</th>
                <th>入库数量</th>
                <th v-if="true">操作</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(row, index) in rows_inbound_order_list_page_data_table" :key="row.id || index">
                <td>{{ displayValue(row["inboundno"]) }}</td>
                <td>{{ displayValue(row["supplierid"]) }}</td>
                <td>{{ displayValue(row["warehouseid"]) }}</td>
                <td><span class="ucg-tag">{{ displayValue(row["status"]) }}</span></td>
                <td>{{ displayValue(row["operatorid"]) }}</td>
                <td>{{ displayValue(row["createdat"]) }}</td>
                <td>{{ displayValue(row["inboundqty"]) }}</td>
                <td v-if="true" class="ucg-row-actions">
                <button class="ucg-btn" type="button" @click="handleAction('inbound_order_list_page_view_detail', row)">查看</button>
                <button class="ucg-btn" type="button" @click="handleAction('inbound_order_list_page_delete_row', row)">删除</button>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </section>

      </section>
      <section class="ucg-card">
      <header class="ucg-card-header"><div></div></header>
        <section class="ucg-card">
        <header class="ucg-card-header">
          <div>
            <h2>暂无数据</h2>
            <p>调整筛选条件后重新查询。</p>
          </div>
        </header>
          <p>调整筛选条件后重新查询。</p>

        </section>

      </section>

    <p v-if="message" class="ucg-message">{{ message }}</p>
  </section>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { fetchUiRows, runUiAction } from '../api/InboundOrderListPageApi.js'
import { mockRows, mockRecord, mockTables } from '../mock/InboundOrderListPageMockData.js'
import { uiContractPage } from '../types/InboundOrderListPageUiContractTypes.js'

const form = reactive({"inboundno": "", "supplierid": "", "warehouseid": "", "keyword": ""})
const loading = ref(false)
const message = ref('')
const activeTabs = reactive({})
const rows_inbound_order_list_page_data_table = ref(mockTables["inbound_order_list_page_data_table"] || mockRows)

onMounted(loadRemoteRows)

async function loadRemoteRows() {
  try {
    const result = await fetchUiRows()
    const remoteRows = Array.isArray(result) ? result : (result?.items || result?.records || result?.rows || [])
    if (!Array.isArray(remoteRows) || remoteRows.length === 0) return
    rows_inbound_order_list_page_data_table.value = remoteRows
  } catch (error) {
    console.warn('UI_CONTRACT remote rows unavailable, using mock rows.', error)
  }
}

function displayValue(value) {
  if (value === null || value === undefined || value === '') return '-'
  if (Array.isArray(value)) return value.join('、')
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

async function handleAction(actionId, payload = {}) {
  loading.value = true
  message.value = ''
  try {
    await runUiAction(actionId, { ...payload, form: { ...form }, page: uiContractPage })
    message.value = `${actionId || '操作'} 已提交到 Node.js 后端接口。`
  } catch (error) {
    message.value = error?.message || '操作失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.ucg-page { display: grid; gap: 18px; color: #0f172a; }
.ucg-page-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; padding: 24px 28px; border: 1px solid #e2e8f0; border-radius: 22px; background: linear-gradient(135deg, #ffffff 0%, #f8fbff 100%); box-shadow: 0 18px 45px rgba(15,23,42,.08); }
.ucg-eyebrow { margin: 0 0 8px; color: #2563eb; font-size: 12px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; }
.ucg-page-header h1 { margin: 0; font-size: 30px; line-height: 1.18; }
.ucg-page-header p { margin: 8px 0 0; color: #64748b; }
.ucg-actions, .ucg-row-actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.ucg-btn { border: 1px solid #cbd5e1; border-radius: 12px; padding: 9px 14px; background: #fff; color: #1e293b; font-weight: 800; cursor: pointer; }
.ucg-btn.primary { background: #2563eb; border-color: #2563eb; color: #fff; }
.ucg-route { color: #64748b; font-size: 13px; }
.ucg-card { border: 1px solid #e2e8f0; border-radius: 20px; background: #fff; padding: 20px; box-shadow: 0 14px 35px rgba(15,23,42,.06); }
.ucg-card-header { display: flex; justify-content: space-between; gap: 12px; margin-bottom: 16px; }
.ucg-card-header h2, .ucg-card-header h3 { margin: 0; font-size: 18px; }
.ucg-card-header p { margin: 6px 0 0; color: #64748b; }
.ucg-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
.ucg-metric { padding: 16px; border: 1px solid #e2e8f0; border-radius: 18px; background: #f8fafc; }
.ucg-metric span { color: #64748b; font-size: 13px; }
.ucg-metric strong { display: block; margin-top: 8px; font-size: 26px; }
.ucg-metric small { color: #16a34a; font-weight: 700; }
.ucg-form { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.ucg-field { display: grid; gap: 7px; color: #334155; font-weight: 800; }
.ucg-field em { color: #ef4444; font-style: normal; }
.ucg-field input, .ucg-field textarea, .ucg-field select { min-height: 38px; border: 1px solid #cbd5e1; border-radius: 12px; padding: 9px 12px; font: inherit; background: #fff; }
.ucg-field textarea { min-height: 82px; resize: vertical; }
.ucg-switch { display: inline-flex; align-items: center; gap: 8px; }
.ucg-table-wrap { overflow: auto; border: 1px solid #e2e8f0; border-radius: 16px; }
.ucg-table { width: 100%; border-collapse: collapse; min-width: 760px; }
.ucg-table th { background: #f8fafc; color: #475569; text-align: left; padding: 12px; font-size: 13px; white-space: nowrap; }
.ucg-table td { border-top: 1px solid #e2e8f0; padding: 12px; color: #334155; }
.ucg-tag { display: inline-flex; padding: 3px 9px; border-radius: 999px; background: #eef2ff; color: #3730a3; font-size: 12px; font-weight: 800; }
.ucg-tabs { display: flex; gap: 8px; border-bottom: 1px solid #e2e8f0; margin-bottom: 14px; }
.ucg-tab { border: 0; background: transparent; padding: 10px 12px; font-weight: 800; cursor: pointer; color: #64748b; }
.ucg-tab.active { color: #2563eb; border-bottom: 2px solid #2563eb; }
.ucg-descriptions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; }
.ucg-descriptions div { display: grid; grid-template-columns: 130px 1fr; border-bottom: 1px solid #e2e8f0; }
.ucg-descriptions dt, .ucg-descriptions dd { margin: 0; padding: 12px; }
.ucg-descriptions dt { background: #f8fafc; color: #64748b; font-weight: 800; }
.ucg-steps, .ucg-timeline { display: grid; gap: 12px; margin: 0; padding: 0; list-style: none; }
.ucg-step, .ucg-timeline-item { display: flex; gap: 12px; align-items: flex-start; padding: 12px; border: 1px solid #e2e8f0; border-radius: 16px; background: #f8fafc; }
.ucg-step-index { display: grid; place-items: center; width: 28px; height: 28px; border-radius: 999px; background: #2563eb; color: #fff; font-weight: 900; }
.ucg-upload { border: 1px dashed #93c5fd; border-radius: 18px; padding: 18px; background: #eff6ff; }
.ucg-upload-list, .ucg-tree { display: grid; gap: 8px; margin-top: 12px; }
.ucg-file, .ucg-tree-node { display: flex; justify-content: space-between; gap: 10px; padding: 10px 12px; border-radius: 12px; background: #fff; border: 1px solid #dbeafe; }
.ucg-chart-bars { display: flex; align-items: end; gap: 12px; height: 180px; padding: 16px; border-radius: 16px; background: #f8fafc; }
.ucg-bar { flex: 1; min-width: 28px; border-radius: 10px 10px 0 0; background: linear-gradient(180deg, #60a5fa, #2563eb); display: flex; align-items: end; justify-content: center; color: #fff; font-size: 12px; font-weight: 900; padding-bottom: 6px; }
.ucg-alert { border-radius: 16px; padding: 14px 16px; background: #fff7ed; border: 1px solid #fed7aa; color: #9a3412; }
.ucg-result { display: grid; place-items: center; text-align: center; gap: 8px; min-height: 180px; }
.ucg-panel { border: 1px solid #dbeafe; border-radius: 18px; background: #f8fbff; padding: 18px; }
.ucg-message { position: sticky; bottom: 16px; justify-self: start; padding: 10px 14px; border-radius: 12px; background: #0f172a; color: #fff; box-shadow: 0 12px 30px rgba(15,23,42,.25); }
@media (max-width: 1100px) {
  .ucg-grid, .ucg-form, .ucg-descriptions { grid-template-columns: 1fr 1fr; }
}
</style>
