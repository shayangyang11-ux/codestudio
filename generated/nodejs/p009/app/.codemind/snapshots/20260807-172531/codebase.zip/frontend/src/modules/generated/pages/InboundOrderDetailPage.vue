<template>
  <section class="page">
    <header class="page-header"><div><p class="eyebrow">INBOUND ORDER DETAIL</p><h2>入库单详情页</h2><p>查看入库单主信息、物料明细、状态流转和关联操作。</p></div><RouterLink class="secondary-link" to="/inbound/orders">返回列表</RouterLink></header>
    <section class="card">
      <div class="toolbar"><select v-model="selectedId" @change="loadDetail"><option v-for="item in rows" :key="item.id" :value="item.id">{{ item.code }} · {{ item.supplier }}</option></select><button @click="loadDetail">刷新详情</button></div>
      <template v-if="order">
        <dl class="info-grid"><div><dt>入库单号</dt><dd>{{ order.code }}</dd></div><div><dt>供应商</dt><dd>{{ order.supplier }}</dd></div><div><dt>仓库</dt><dd>{{ order.warehouse }}</dd></div><div><dt>状态</dt><dd><span class="tag">{{ order.status }}</span></dd></div><div><dt>数量</dt><dd>{{ order.quantity }}</dd></div><div><dt>预计到货</dt><dd>{{ order.expectedArrival }}</dd></div><div><dt>联系人</dt><dd>{{ order.contact || '-' }}</dd></div><div><dt>联系电话</dt><dd>{{ order.phone || '-' }}</dd></div></dl>
        <section class="sub-card"><h3>入库明细</h3><table><thead><tr><th>SKU</th><th>物料名称</th><th>计划数量</th><th>实收数量</th><th>单位</th><th>库位</th></tr></thead><tbody><tr v-for="item in order.items || []" :key="item.sku"><td>{{ item.sku }}</td><td>{{ item.name }}</td><td>{{ item.plannedQty }}</td><td>{{ item.actualQty }}</td><td>{{ item.unit }}</td><td>{{ item.location }}</td></tr></tbody></table></section>
        <section class="sub-card"><h3>状态流转</h3><ol class="timeline"><li v-for="history in order.auditHistory || []" :key="`${history.time}-${history.action}`"><strong>{{ history.action }}</strong><span>{{ history.time }} · {{ history.operator }}</span><p>{{ history.comment }}</p></li></ol></section>
      </template>
      <p v-if="message" class="message">{{ message }}</p>
    </section>
  </section>
</template>
<script setup>
import { onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
const route = useRoute()
const rows = ref([])
const selectedId = ref('')
const order = ref(null)
const message = ref('')
async function loadOrders() { const response = await fetch('/api/inbound/orders'); const payload = await response.json(); rows.value = payload?.data?.items || []; selectedId.value = String(route.query.id || selectedId.value || rows.value[0]?.id || ''); await loadDetail() }
async function loadDetail() { if (!selectedId.value) return; message.value = ''; try { const response = await fetch(`/api/inbound/orders/${encodeURIComponent(selectedId.value)}`); const payload = await response.json(); if (!response.ok || !payload.success) throw new Error(payload.message || `HTTP ${response.status}`); order.value = payload.data } catch (error) { message.value = `详情加载失败：${error.message}` } }
onMounted(loadOrders)
</script>

<style scoped>
.page { display: flex; flex-direction: column; gap: 22px; }
.page-header, .card, .stats-grid article, .sub-card { background: #fff; border: 1px solid #dbe5f5; border-radius: 18px; box-shadow: 0 18px 40px rgba(15,23,42,.06); padding: 26px 28px; }
.page-header { display: flex; justify-content: space-between; align-items: center; }
.eyebrow { color: #2563eb; font-weight: 700; letter-spacing: .08em; margin: 0 0 8px; }
h2 { margin: 0 0 10px; font-size: 28px; }
p { color: #475569; }
.secondary-link, .primary-link, a { color: #2563eb; text-decoration: none; font-weight: 700; }
.primary-link, button { border: 0; background: #2563eb; color: #fff; border-radius: 10px; padding: 10px 16px; cursor: pointer; }
.ghost { background: #e0e7ff; color: #1d4ed8; }
.danger { background: #dc2626; }
input, select, textarea { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; font: inherit; }
textarea { min-height: 92px; resize: vertical; }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px 20px; }
label { display: flex; flex-direction: column; gap: 8px; color: #334155; font-weight: 700; }
.wide { grid-column: 1 / -1; }
.actions, .toolbar { display: flex; gap: 12px; }
.message, .hint { color: #2563eb; font-weight: 700; }
.tag { background: #eff6ff; color: #1d4ed8; border-radius: 999px; padding: 4px 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 12px 10px; border-bottom: 1px solid #e5e7eb; }
th { color: #475569; font-size: 13px; }
.stats-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.stats-grid span { display: block; color: #64748b; margin-bottom: 8px; }
.stats-grid strong { font-size: 28px; }
.info-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
dt { color: #64748b; }
dd { margin: 4px 0 0; font-weight: 700; }
.timeline { padding-left: 20px; }
.timeline span { display: block; color: #64748b; margin: 4px 0; }
.timeline p { margin-top: 0; }
.order-list { list-style: none; padding: 0; margin: 16px 0 0; display: flex; flex-direction: column; gap: 10px; }
.order-list li { border: 1px solid #dbe5f5; border-radius: 12px; padding: 12px; cursor: pointer; }
.order-list li.active { border-color: #2563eb; background: #eff6ff; }
.layout { display: grid; grid-template-columns: 360px 1fr; gap: 18px; }
.summary, .result { margin-top: 16px; background: #f8fafc; border: 1px solid #dbe5f5; border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; }
</style>
