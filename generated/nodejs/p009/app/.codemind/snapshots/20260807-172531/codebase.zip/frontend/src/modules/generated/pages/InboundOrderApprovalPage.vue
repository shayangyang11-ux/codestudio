<template>
  <section class="page">
    <header class="page-header"><div><p class="eyebrow">INBOUND APPROVAL</p><h2>入库单审核页</h2><p>审批入库单、提交审核意见，并同步单据状态和审核记录。</p></div><RouterLink class="secondary-link" to="/inbound/orders">返回列表</RouterLink></header>
    <div class="layout">
      <section class="card"><h3>待处理单据</h3><button @click="loadOrders">刷新</button><ul class="order-list"><li v-for="item in rows" :key="item.id" :class="{ active: selected?.id === item.id }" @click="selectOrder(item)"><strong>{{ item.code }}</strong><span>{{ item.supplier }} / {{ item.status }}</span></li></ul></section>
      <section class="card">
        <template v-if="selected">
          <h3>{{ selected.code }}</h3>
          <dl class="info-grid"><div><dt>供应商</dt><dd>{{ selected.supplier }}</dd></div><div><dt>仓库</dt><dd>{{ selected.warehouse }}</dd></div><div><dt>数量</dt><dd>{{ selected.quantity }}</dd></div><div><dt>状态</dt><dd><span class="tag">{{ selected.status }}</span></dd></div></dl>
          <label><span>审核意见</span><textarea v-model.trim="comment" placeholder="请输入审核意见" /></label>
          <div class="actions"><button @click="submitApproval('APPROVE')">通过</button><button class="danger" @click="submitApproval('REJECT')">驳回</button></div>
          <p v-if="message" class="message">{{ message }}</p>
          <h4>审核记录</h4><ol class="timeline"><li v-for="history in selected.auditHistory || []" :key="`${history.time}-${history.action}`"><strong>{{ history.action }}</strong><span>{{ history.time }} · {{ history.operator }}</span><p>{{ history.comment }}</p></li></ol>
        </template>
        <p v-else>请选择待审核入库单。</p>
      </section>
    </div>
  </section>
</template>
<script setup>
import { onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
const route = useRoute()
const rows = ref([])
const selected = ref(null)
const comment = ref('资料齐全，同意入库。')
const message = ref('')
async function loadOrders() {
  const response = await fetch('/api/inbound/orders')
  const payload = await response.json()
  rows.value = payload?.data?.items || []
  const id = route.query.id
  selected.value = rows.value.find((item) => item.id === id || item.code === id) || rows.value.find((item) => String(item.status).includes('待')) || rows.value[0] || null
}
function selectOrder(item) { selected.value = item; message.value = '' }
async function submitApproval(decision) {
  if (!selected.value) return
  const response = await fetch(`/api/inbound/orders/${encodeURIComponent(selected.value.id)}/approval`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ decision, comment: comment.value }) })
  const payload = await response.json()
  if (!response.ok || !payload.success) { message.value = payload.message || `提交失败 HTTP ${response.status}`; return }
  selected.value = payload.data; rows.value = rows.value.map((item) => item.id === payload.data.id ? payload.data : item); message.value = payload.message
}
onMounted(loadOrders)
</script>

<style scoped>
.page { display: flex; flex-direction: column; gap: 22px; }
.page-header, .card, .stats-grid article, .sub-card { background: #fff; border: 1px solid #dbe5f5; border-radius: 18px; box-shadow: 0 18px 40px rgba(15,23,42,.06); padding: 26px 28px; }
.page-header { display: flex; justify-content: space-between; align-items: center; }
.eyebrow { color: #2563eb; font-weight: 700; letter-spacing: .08em; margin: 0 0 8px; }
h2 { margin: 0 0 10px; font-size: 28px; }
p { color: #475569; }
.secondary-link, .primary-link, a { color: #2563eb; text-decoration: none; font-weight: 700; }
.primary-link, button { border: 0; background: #2563eb; color: #fff; border-radius: 10px; padding: 10px 16px; cursor: pointer; }
.ghost { background: #e0e7ff; color: #1d4ed8; }
.danger { background: #dc2626; }
input, select, textarea { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; font: inherit; }
textarea { min-height: 92px; resize: vertical; }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px 20px; }
label { display: flex; flex-direction: column; gap: 8px; color: #334155; font-weight: 700; }
.wide { grid-column: 1 / -1; }
.actions, .toolbar { display: flex; gap: 12px; }
.message, .hint { color: #2563eb; font-weight: 700; }
.tag { background: #eff6ff; color: #1d4ed8; border-radius: 999px; padding: 4px 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 12px 10px; border-bottom: 1px solid #e5e7eb; }
th { color: #475569; font-size: 13px; }
.stats-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.stats-grid span { display: block; color: #64748b; margin-bottom: 8px; }
.stats-grid strong { font-size: 28px; }
.info-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
dt { color: #64748b; }
dd { margin: 4px 0 0; font-weight: 700; }
.timeline { padding-left: 20px; }
.timeline span { display: block; color: #64748b; margin: 4px 0; }
.timeline p { margin-top: 0; }
.order-list { list-style: none; padding: 0; margin: 16px 0 0; display: flex; flex-direction: column; gap: 10px; }
.order-list li { border: 1px solid #dbe5f5; border-radius: 12px; padding: 12px; cursor: pointer; }
.order-list li.active { border-color: #2563eb; background: #eff6ff; }
.layout { display: grid; grid-template-columns: 360px 1fr; gap: 18px; }
.summary, .result { margin-top: 16px; background: #f8fafc; border: 1px solid #dbe5f5; border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; }
</style>
