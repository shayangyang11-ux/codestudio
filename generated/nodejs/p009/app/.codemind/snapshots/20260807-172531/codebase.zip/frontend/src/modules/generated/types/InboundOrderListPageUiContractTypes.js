export const uiContractPage = {"title": "入库单列表页", "pageKey": "inbound_order_list_page", "routePath": "/inbound/orders", "pageKind": "LIST_PAGE", "componentCount": 0, "fieldCount": 0, "columnCount": 0}

export const uiContractFields = []

export const uiContractColumns = []

export const uiContractActions = [{"id": "inbound_order_list_page_query", "label": "查询"}, {"id": "inbound_order_list_page_reset_filters", "label": "重置"}, {"id": "inbound_order_list_page_create", "label": "新增"}, {"id": "inbound_order_list_page_export", "label": "导出"}, {"id": "inbound_order_list_page_delete_row", "label": "删除"}, {"id": "inbound_order_list_page_view_detail", "label": "查看"}, {"id": "inbound_order_query_action", "label": "入库单查询"}]
