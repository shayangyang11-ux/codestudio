export const mockRecord = {}

export const mockRows = [{}]

export const mockTables = {}

export const mockMeta = {
  generatedBy: 'A9.10.5_UI_CONTRACT_TO_VUE_CODEGEN',
  source: 'confirmedUiContract',
}
