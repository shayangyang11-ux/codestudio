<template>
  <section class="page">
    <header class="page-header"><div><p class="eyebrow">INBOUND QUANTITY CONTROL</p><h2>入库单数量编辑页</h2><p>调整入库数量、记录差异原因，并触发库存台账同步。</p></div><RouterLink class="secondary-link" to="/inbound/orders">返回列表</RouterLink></header>
    <section class="card">
      <div class="form-grid"><label><span>选择入库单</span><select v-model="selectedId" @change="syncSelected"><option v-for="item in rows" :key="item.id" :value="item.id">{{ item.code }} · {{ item.supplier }}</option></select></label><label><span>当前数量</span><input :value="selected?.quantity || 0" disabled /></label><label><span>调整后数量</span><input v-model.number="quantity" type="number" min="1" /></label><label><span>差异原因</span><input v-model.trim="reason" placeholder="例如：实收数量差异、破损剔除、复核调整" /></label></div>
      <div v-if="selected" class="summary"><strong>{{ selected.code }}</strong><span>{{ selected.supplier }} / {{ selected.warehouse }} / {{ selected.status }}</span></div>
      <div class="actions"><button @click="submitQuantity">保存数量调整</button><button class="ghost" @click="loadOrders">重新读取</button></div>
      <p v-if="message" class="message">{{ message }}</p>
    </section>
  </section>
</template>
<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
const route = useRoute()
const rows = ref([])
const selectedId = ref('')
const quantity = ref(1)
const reason = ref('实收到货数量复核调整')
const message = ref('')
const selected = computed(() => rows.value.find((item) => item.id === selectedId.value) || null)
async function loadOrders() { const response = await fetch('/api/inbound/orders'); const payload = await response.json(); rows.value = payload?.data?.items || []; selectedId.value = String(route.query.id || selectedId.value || rows.value[0]?.id || ''); syncSelected() }
function syncSelected() { if (selected.value) quantity.value = Number(selected.value.quantity || 1); message.value = '' }
async function submitQuantity() {
  if (!selected.value) return
  const response = await fetch(`/api/inbound/orders/${encodeURIComponent(selected.value.id)}/quantity`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ quantity: quantity.value, reason: reason.value }) })
  const payload = await response.json()
  if (!response.ok || !payload.success) { message.value = payload.message || `保存失败 HTTP ${response.status}`; return }
  rows.value = rows.value.map((item) => item.id === payload.data.order.id ? payload.data.order : item)
  message.value = `${payload.message}：${payload.data.beforeQuantity} → ${payload.data.afterQuantity}，${payload.data.inventorySyncStatus}`
}
onMounted(loadOrders)
</script>

<style scoped>
.page { display: flex; flex-direction: column; gap: 22px; }
.page-header, .card, .stats-grid article, .sub-card { background: #fff; border: 1px solid #dbe5f5; border-radius: 18px; box-shadow: 0 18px 40px rgba(15,23,42,.06); padding: 26px 28px; }
.page-header { display: flex; justify-content: space-between; align-items: center; }
.eyebrow { color: #2563eb; font-weight: 700; letter-spacing: .08em; margin: 0 0 8px; }
h2 { margin: 0 0 10px; font-size: 28px; }
p { color: #475569; }
.secondary-link, .primary-link, a { color: #2563eb; text-decoration: none; font-weight: 700; }
.primary-link, button { border: 0; background: #2563eb; color: #fff; border-radius: 10px; padding: 10px 16px; cursor: pointer; }
.ghost { background: #e0e7ff; color: #1d4ed8; }
.danger { background: #dc2626; }
input, select, textarea { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; font: inherit; }
textarea { min-height: 92px; resize: vertical; }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px 20px; }
label { display: flex; flex-direction: column; gap: 8px; color: #334155; font-weight: 700; }
.wide { grid-column: 1 / -1; }
.actions, .toolbar { display: flex; gap: 12px; }
.message, .hint { color: #2563eb; font-weight: 700; }
.tag { background: #eff6ff; color: #1d4ed8; border-radius: 999px; padding: 4px 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 12px 10px; border-bottom: 1px solid #e5e7eb; }
th { color: #475569; font-size: 13px; }
.stats-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.stats-grid span { display: block; color: #64748b; margin-bottom: 8px; }
.stats-grid strong { font-size: 28px; }
.info-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
dt { color: #64748b; }
dd { margin: 4px 0 0; font-weight: 700; }
.timeline { padding-left: 20px; }
.timeline span { display: block; color: #64748b; margin: 4px 0; }
.timeline p { margin-top: 0; }
.order-list { list-style: none; padding: 0; margin: 16px 0 0; display: flex; flex-direction: column; gap: 10px; }
.order-list li { border: 1px solid #dbe5f5; border-radius: 12px; padding: 12px; cursor: pointer; }
.order-list li.active { border-color: #2563eb; background: #eff6ff; }
.layout { display: grid; grid-template-columns: 360px 1fr; gap: 18px; }
.summary, .result { margin-top: 16px; background: #f8fafc; border: 1px solid #dbe5f5; border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; }
</style>
