<template>
  <section class="page">
    <header class="page-header">
      <div><p class="eyebrow">INBOUND ORDER MANAGEMENT</p><h2>入库单列表页</h2><p>用于查看、筛选和处理仓储入库单。</p></div>
      <RouterLink class="primary-link" to="/inbound/orders/create">新建入库单</RouterLink>
    </header>
    <div class="stats-grid">
      <article><span>待审核</span><strong>{{ pendingCount }}</strong></article>
      <article><span>今日入库</span><strong>{{ rows.length }}</strong></article>
      <article><span>异常单据</span><strong>{{ exceptionCount }}</strong></article>
    </div>
    <section class="card">
      <div class="toolbar"><input v-model="keyword" placeholder="搜索单号、供应商、仓库、状态" @keyup.enter="loadOrders" /><button @click="loadOrders">刷新数据</button></div>
      <p v-if="apiMessage" class="hint">{{ apiMessage }}</p>
      <table>
        <thead><tr><th>入库单号</th><th>供应商</th><th>仓库</th><th>状态</th><th>数量</th><th>预计到货</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="item in filteredRows" :key="item.id">
            <td>{{ item.code }}</td><td>{{ item.supplier }}</td><td>{{ item.warehouse }}</td><td><span class="tag">{{ item.status }}</span></td><td>{{ item.quantity }}</td><td>{{ item.expectedArrival }}</td>
            <td class="actions">
              <RouterLink :to="`/inbound/orders/detail?id=${encodeURIComponent(item.id)}`">详情</RouterLink>
              <RouterLink :to="`/inbound/orders/approval?id=${encodeURIComponent(item.id)}`">审核</RouterLink>
              <RouterLink :to="`/inbound/orders/quantity-edit?id=${encodeURIComponent(item.id)}`">改数量</RouterLink>
            </td>
          </tr>
        </tbody>
      </table>
    </section>
  </section>
</template>
<script setup>
import { computed, onMounted, ref } from 'vue'
const keyword = ref('')
const apiMessage = ref('')
const rows = ref([])
const filteredRows = computed(() => {
  const q = keyword.value.trim().toLowerCase()
  if (!q) return rows.value
  return rows.value.filter((item) => [item.code, item.supplier, item.warehouse, item.status].some((value) => String(value || '').toLowerCase().includes(q)))
})
const pendingCount = computed(() => rows.value.filter((item) => String(item.status).includes('待')).length)
const exceptionCount = computed(() => rows.value.filter((item) => String(item.status).includes('异常')).length)
async function loadOrders() {
  const params = keyword.value ? `?keyword=${encodeURIComponent(keyword.value)}` : ''
  const response = await fetch(`/api/inbound/orders${params}`)
  const payload = await response.json()
  rows.value = payload?.data?.items || []
  apiMessage.value = '已从后端接口加载入库单数据。'
}
onMounted(loadOrders)
</script>

<style scoped>
.page { display: flex; flex-direction: column; gap: 22px; }
.page-header, .card, .stats-grid article, .sub-card { background: #fff; border: 1px solid #dbe5f5; border-radius: 18px; box-shadow: 0 18px 40px rgba(15,23,42,.06); padding: 26px 28px; }
.page-header { display: flex; justify-content: space-between; align-items: center; }
.eyebrow { color: #2563eb; font-weight: 700; letter-spacing: .08em; margin: 0 0 8px; }
h2 { margin: 0 0 10px; font-size: 28px; }
p { color: #475569; }
.secondary-link, .primary-link, a { color: #2563eb; text-decoration: none; font-weight: 700; }
.primary-link, button { border: 0; background: #2563eb; color: #fff; border-radius: 10px; padding: 10px 16px; cursor: pointer; }
.ghost { background: #e0e7ff; color: #1d4ed8; }
.danger { background: #dc2626; }
input, select, textarea { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; font: inherit; }
textarea { min-height: 92px; resize: vertical; }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px 20px; }
label { display: flex; flex-direction: column; gap: 8px; color: #334155; font-weight: 700; }
.wide { grid-column: 1 / -1; }
.actions, .toolbar { display: flex; gap: 12px; }
.message, .hint { color: #2563eb; font-weight: 700; }
.tag { background: #eff6ff; color: #1d4ed8; border-radius: 999px; padding: 4px 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 12px 10px; border-bottom: 1px solid #e5e7eb; }
th { color: #475569; font-size: 13px; }
.stats-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.stats-grid span { display: block; color: #64748b; margin-bottom: 8px; }
.stats-grid strong { font-size: 28px; }
.info-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
dt { color: #64748b; }
dd { margin: 4px 0 0; font-weight: 700; }
.timeline { padding-left: 20px; }
.timeline span { display: block; color: #64748b; margin: 4px 0; }
.timeline p { margin-top: 0; }
.order-list { list-style: none; padding: 0; margin: 16px 0 0; display: flex; flex-direction: column; gap: 10px; }
.order-list li { border: 1px solid #dbe5f5; border-radius: 12px; padding: 12px; cursor: pointer; }
.order-list li.active { border-color: #2563eb; background: #eff6ff; }
.layout { display: grid; grid-template-columns: 360px 1fr; gap: 18px; }
.summary, .result { margin-top: 16px; background: #f8fafc; border: 1px solid #dbe5f5; border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; }
</style>
