export const uiContractPage = {"title": "入库单创建页", "pageKey": "inbound_order_create_page", "routePath": "/inbound/orders/create", "pageKind": "FORM_PAGE", "componentCount": 0, "fieldCount": 0, "columnCount": 0}

export const uiContractFields = []

export const uiContractColumns = []

export const uiContractActions = [{"id": "back_to_list", "label": "返回列表"}, {"id": "save_draft", "label": "保存草稿"}, {"id": "submit_order", "label": "提交入库单"}, {"id": "cancel_create", "label": "取消"}, {"id": "add_item", "label": "添加商品"}, {"id": "delete_item", "label": "删除"}, {"id": "show_save_success", "label": "保存成功"}, {"id": "show_save_error", "label": "保存失败"}, {"id": "show_submit_success", "label": "提交成功"}, {"id": "show_submit_error", "label": "提交失败"}, {"id": "basic_info_form_submit", "label": "提交"}, {"id": "basic_info_form_reset", "label": "重置"}, {"id": "inbound_order_create_page_save_draft", "label": "保存草稿"}, {"id": "inbound_order_create_page_submit", "label": "提交"}, {"id": "inbound_order_create_page_cancel", "label": "取消"}, {"id": "inbound_order_create_page_add_item", "label": "添加商品"}, {"id": "inbound_order_create_page_remove_item", "label": "删除"}, {"id": "inbound_order_create_action", "label": "入库单创建"}, {"id": "inbound_order_create_page_basic_form_submit", "label": "提交"}, {"id": "inbound_order_create_page_basic_form_reset", "label": "重置"}]
