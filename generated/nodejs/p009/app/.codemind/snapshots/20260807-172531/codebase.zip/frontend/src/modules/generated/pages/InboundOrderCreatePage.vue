<template>
  <section class="page">
    <header class="page-header"><div><p class="eyebrow">INBOUND ORDER CREATION</p><h2>入库单创建页</h2><p>录入供应商、仓库、预计到货时间、数量和明细，提交后写入 Node.js 后端。</p></div><RouterLink class="secondary-link" to="/inbound/orders">返回列表</RouterLink></header>
    <section class="card">
      <h3>基础信息</h3>
      <form class="form-grid" @submit.prevent="submitOrder">
        <label><span>供应商</span><input v-model.trim="draft.supplier" required placeholder="请输入供应商名称" /></label>
        <label><span>入库仓库</span><select v-model="draft.warehouse" required><option value="">请选择仓库</option><option>上海主仓</option><option>苏州备件仓</option><option>北京中心仓</option></select></label>
        <label><span>预计到货时间</span><input v-model="draft.expectedArrival" type="datetime-local" required /></label>
        <label><span>入库数量</span><input v-model.number="draft.quantity" type="number" min="1" required /></label>
        <label><span>联系人</span><input v-model.trim="draft.contact" placeholder="供应商联系人" /></label>
        <label><span>联系电话</span><input v-model.trim="draft.phone" placeholder="联系电话" /></label>
        <label class="wide"><span>备注</span><textarea v-model.trim="draft.remark" placeholder="填写到货注意事项、质检要求或异常说明" /></label>
        <div class="actions wide"><button type="submit" :disabled="submitting">{{ submitting ? '提交中...' : '提交入库单' }}</button><button type="button" class="ghost" @click="resetDraft">重置</button></div>
      </form>
      <p v-if="message" class="message">{{ message }}</p>
      <div v-if="createdOrder" class="result"><strong>已创建：{{ createdOrder.code }}</strong><span>{{ createdOrder.supplier }} / {{ createdOrder.warehouse }} / {{ createdOrder.quantity }} 件</span><RouterLink :to="`/inbound/orders/detail?id=${encodeURIComponent(createdOrder.id)}`">查看详情</RouterLink></div>
    </section>
  </section>
</template>
<script setup>
import { reactive, ref } from 'vue'
const submitting = ref(false)
const message = ref('')
const createdOrder = ref(null)
const draft = reactive({ supplier: '', warehouse: '', expectedArrival: '', quantity: 1, contact: '', phone: '', remark: '' })
function resetDraft() { Object.assign(draft, { supplier: '', warehouse: '', expectedArrival: '', quantity: 1, contact: '', phone: '', remark: '' }); createdOrder.value = null; message.value = '' }
async function submitOrder() {
  submitting.value = true; message.value = ''; createdOrder.value = null
  try {
    const response = await fetch('/api/inbound/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(draft) })
    const payload = await response.json()
    if (!response.ok || !payload.success) throw new Error(payload.message || `HTTP ${response.status}`)
    createdOrder.value = payload.data; message.value = payload.message || '入库单已创建。'
  } catch (error) { message.value = `提交失败：${error.message}` } finally { submitting.value = false }
}
</script>

<style scoped>
.page { display: flex; flex-direction: column; gap: 22px; }
.page-header, .card, .stats-grid article, .sub-card { background: #fff; border: 1px solid #dbe5f5; border-radius: 18px; box-shadow: 0 18px 40px rgba(15,23,42,.06); padding: 26px 28px; }
.page-header { display: flex; justify-content: space-between; align-items: center; }
.eyebrow { color: #2563eb; font-weight: 700; letter-spacing: .08em; margin: 0 0 8px; }
h2 { margin: 0 0 10px; font-size: 28px; }
p { color: #475569; }
.secondary-link, .primary-link, a { color: #2563eb; text-decoration: none; font-weight: 700; }
.primary-link, button { border: 0; background: #2563eb; color: #fff; border-radius: 10px; padding: 10px 16px; cursor: pointer; }
.ghost { background: #e0e7ff; color: #1d4ed8; }
.danger { background: #dc2626; }
input, select, textarea { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; font: inherit; }
textarea { min-height: 92px; resize: vertical; }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px 20px; }
label { display: flex; flex-direction: column; gap: 8px; color: #334155; font-weight: 700; }
.wide { grid-column: 1 / -1; }
.actions, .toolbar { display: flex; gap: 12px; }
.message, .hint { color: #2563eb; font-weight: 700; }
.tag { background: #eff6ff; color: #1d4ed8; border-radius: 999px; padding: 4px 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 12px 10px; border-bottom: 1px solid #e5e7eb; }
th { color: #475569; font-size: 13px; }
.stats-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
.stats-grid span { display: block; color: #64748b; margin-bottom: 8px; }
.stats-grid strong { font-size: 28px; }
.info-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
dt { color: #64748b; }
dd { margin: 4px 0 0; font-weight: 700; }
.timeline { padding-left: 20px; }
.timeline span { display: block; color: #64748b; margin: 4px 0; }
.timeline p { margin-top: 0; }
.order-list { list-style: none; padding: 0; margin: 16px 0 0; display: flex; flex-direction: column; gap: 10px; }
.order-list li { border: 1px solid #dbe5f5; border-radius: 12px; padding: 12px; cursor: pointer; }
.order-list li.active { border-color: #2563eb; background: #eff6ff; }
.layout { display: grid; grid-template-columns: 360px 1fr; gap: 18px; }
.summary, .result { margin-top: 16px; background: #f8fafc; border: 1px solid #dbe5f5; border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; }
</style>
