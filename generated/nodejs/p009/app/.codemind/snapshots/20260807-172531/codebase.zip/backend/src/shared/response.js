function isExpressResponse(value) {
  return value && typeof value.status === 'function' && typeof value.json === 'function'
}

function normalizeError(errorOrMessage) {
  if (errorOrMessage instanceof Error) {
    return {
      message: errorOrMessage.message || 'Internal server error',
      details: errorOrMessage.stack,
      status: Number(errorOrMessage.status || errorOrMessage.statusCode || 500),
    }
  }

  if (typeof errorOrMessage === 'object' && errorOrMessage !== null) {
    return {
      message: errorOrMessage.message || 'Request failed',
      details: errorOrMessage,
      status: Number(errorOrMessage.status || errorOrMessage.statusCode || 500),
    }
  }

  return {
    message: errorOrMessage || 'Request failed',
    details: undefined,
    status: 500,
  }
}

export function ok(target = null, data = null, message = 'OK', meta = undefined) {
  const body = {
    success: true,
    code: 0,
    message,
    data: isExpressResponse(target) ? data : target,
  }

  if (meta !== undefined) {
    body.meta = meta
  }

  if (isExpressResponse(target)) {
    return target.json(body)
  }

  return body
}

export function fail(target = null, message = 'Request failed', status = 400, details = undefined) {
  if (!isExpressResponse(target)) {
    const normalized = normalizeError(target || message)
    return {
      success: false,
      code: Number(status || normalized.status || 400),
      message: typeof target === 'string' ? target : normalized.message,
      details: details !== undefined ? details : normalized.details,
    }
  }

  const body = {
    success: false,
    code: status,
    message,
  }

  if (details !== undefined) {
    body.details = details
  }

  return target.status(status).json(body)
}

export function page(items = [], total = 0, pageNo = 1, pageSize = 20) {
  return ok({
    items,
    total,
    pageNo,
    pageSize,
  })
}

export function sendOk(res, data = null, meta = undefined, message = 'OK') {
  return ok(res, data, message, meta)
}

export function sendSuccess(res, data = null, message = 'OK', status = 200, meta = undefined) {
  const body = {
    success: true,
    code: 0,
    message,
    data,
  }

  if (meta !== undefined) {
    body.meta = meta
  }

  return res.status(status).json(body)
}

export function sendError(res, errorOrMessage = 'Request failed', status = undefined, details = undefined) {
  const normalized = normalizeError(errorOrMessage)
  const resolvedStatus = Number(status || normalized.status || 500)

  const body = {
    success: false,
    code: resolvedStatus,
    message: normalized.message,
  }

  if (details !== undefined) {
    body.details = details
  } else if (normalized.details !== undefined) {
    body.details = normalized.details
  }

  return res.status(resolvedStatus).json(body)
}

export function sendPaginated(res, items = [], total = 0, pageNo = 1, pageSize = 20, message = 'OK') {
  return sendSuccess(res, {
    items,
    total,
    pageNo,
    pageSize,
  }, message)
}

export function badRequest(res, message = 'Bad request', details = undefined) {
  return sendError(res, message, 400, details)
}

export function notFound(res, message = 'Not found', details = undefined) {
  return sendError(res, message, 404, details)
}

export function serverError(res, error = 'Internal server error', details = undefined) {
  return sendError(res, error, 500, details)
}

export default {
  ok,
  fail,
  page,
  sendOk,
  sendSuccess,
  sendError,
  sendPaginated,
  badRequest,
  notFound,
  serverError,
}
