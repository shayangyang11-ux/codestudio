﻿import * as appModule from './src/app.js'

const port = Number(process.env.PORT || 3101)

const app =
  typeof appModule.createApp === 'function'
    ? appModule.createApp()
    : appModule.default || appModule.app

if (!app || typeof app.listen !== 'function') {
  console.error('[CodeMind] backend app module did not export an Express app or createApp().')
  console.error('[CodeMind] available exports:', Object.keys(appModule))
  process.exit(1)
}

app.listen(port, '0.0.0.0', () => {
  console.log(`[CodeMind] Generated backend listening on http://127.0.0.1:${port}`)
})
