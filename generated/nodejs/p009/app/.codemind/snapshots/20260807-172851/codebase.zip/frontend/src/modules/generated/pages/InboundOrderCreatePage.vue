<template>
  <section class="ucg-page">
    <header class="ucg-page-header">
      <div>
        <p class="ucg-eyebrow">Confirmed UI_CONTRACT</p>
        <h1>入库单创建页</h1>
        <p>录入供应商、仓库、经办人等基本信息，并添加入库商品明细，保存或提交入库单。</p>
      </div>
      <div class="ucg-actions">
          <span class="ucg-route">{{ uiContractPage.routePath }}</span>
      </div>
    </header>

      <section class="ucg-card"><p>当前 UI_CONTRACT 暂无可渲染组件。</p></section>

    <p v-if="message" class="ucg-message">{{ message }}</p>
  </section>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { fetchUiRows, runUiAction } from '../api/InboundOrderCreatePageApi.js'
import { mockRows, mockRecord, mockTables } from '../mock/InboundOrderCreatePageMockData.js'
import { uiContractPage } from '../types/InboundOrderCreatePageUiContractTypes.js'

const form = reactive({})
const loading = ref(false)
const message = ref('')
const activeTabs = reactive({})

function displayValue(value) {
  if (value === null || value === undefined || value === '') return '-'
  if (Array.isArray(value)) return value.join('、')
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

async function handleAction(actionId, payload = {}) {
  loading.value = true
  message.value = ''
  try {
    await runUiAction(actionId, { ...payload, form: { ...form }, page: uiContractPage })
    message.value = `${actionId || '操作'} 已提交到 Node.js 后端接口。`
  } catch (error) {
    message.value = error?.message || '操作失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.ucg-page { display: grid; gap: 18px; color: #0f172a; }
.ucg-page-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; padding: 24px 28px; border: 1px solid #e2e8f0; border-radius: 22px; background: linear-gradient(135deg, #ffffff 0%, #f8fbff 100%); box-shadow: 0 18px 45px rgba(15,23,42,.08); }
.ucg-eyebrow { margin: 0 0 8px; color: #2563eb; font-size: 12px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; }
.ucg-page-header h1 { margin: 0; font-size: 30px; line-height: 1.18; }
.ucg-page-header p { margin: 8px 0 0; color: #64748b; }
.ucg-actions, .ucg-row-actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.ucg-btn { border: 1px solid #cbd5e1; border-radius: 12px; padding: 9px 14px; background: #fff; color: #1e293b; font-weight: 800; cursor: pointer; }
.ucg-btn.primary { background: #2563eb; border-color: #2563eb; color: #fff; }
.ucg-route { color: #64748b; font-size: 13px; }
.ucg-card { border: 1px solid #e2e8f0; border-radius: 20px; background: #fff; padding: 20px; box-shadow: 0 14px 35px rgba(15,23,42,.06); }
.ucg-card-header { display: flex; justify-content: space-between; gap: 12px; margin-bottom: 16px; }
.ucg-card-header h2, .ucg-card-header h3 { margin: 0; font-size: 18px; }
.ucg-card-header p { margin: 6px 0 0; color: #64748b; }
.ucg-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
.ucg-metric { padding: 16px; border: 1px solid #e2e8f0; border-radius: 18px; background: #f8fafc; }
.ucg-metric span { color: #64748b; font-size: 13px; }
.ucg-metric strong { display: block; margin-top: 8px; font-size: 26px; }
.ucg-metric small { color: #16a34a; font-weight: 700; }
.ucg-form { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.ucg-field { display: grid; gap: 7px; color: #334155; font-weight: 800; }
.ucg-field em { color: #ef4444; font-style: normal; }
.ucg-field input, .ucg-field textarea, .ucg-field select { min-height: 38px; border: 1px solid #cbd5e1; border-radius: 12px; padding: 9px 12px; font: inherit; background: #fff; }
.ucg-field textarea { min-height: 82px; resize: vertical; }
.ucg-switch { display: inline-flex; align-items: center; gap: 8px; }
.ucg-table-wrap { overflow: auto; border: 1px solid #e2e8f0; border-radius: 16px; }
.ucg-table { width: 100%; border-collapse: collapse; min-width: 760px; }
.ucg-table th { background: #f8fafc; color: #475569; text-align: left; padding: 12px; font-size: 13px; white-space: nowrap; }
.ucg-table td { border-top: 1px solid #e2e8f0; padding: 12px; color: #334155; }
.ucg-tag { display: inline-flex; padding: 3px 9px; border-radius: 999px; background: #eef2ff; color: #3730a3; font-size: 12px; font-weight: 800; }
.ucg-tabs { display: flex; gap: 8px; border-bottom: 1px solid #e2e8f0; margin-bottom: 14px; }
.ucg-tab { border: 0; background: transparent; padding: 10px 12px; font-weight: 800; cursor: pointer; color: #64748b; }
.ucg-tab.active { color: #2563eb; border-bottom: 2px solid #2563eb; }
.ucg-descriptions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; }
.ucg-descriptions div { display: grid; grid-template-columns: 130px 1fr; border-bottom: 1px solid #e2e8f0; }
.ucg-descriptions dt, .ucg-descriptions dd { margin: 0; padding: 12px; }
.ucg-descriptions dt { background: #f8fafc; color: #64748b; font-weight: 800; }
.ucg-steps, .ucg-timeline { display: grid; gap: 12px; margin: 0; padding: 0; list-style: none; }
.ucg-step, .ucg-timeline-item { display: flex; gap: 12px; align-items: flex-start; padding: 12px; border: 1px solid #e2e8f0; border-radius: 16px; background: #f8fafc; }
.ucg-step-index { display: grid; place-items: center; width: 28px; height: 28px; border-radius: 999px; background: #2563eb; color: #fff; font-weight: 900; }
.ucg-upload { border: 1px dashed #93c5fd; border-radius: 18px; padding: 18px; background: #eff6ff; }
.ucg-upload-list, .ucg-tree { display: grid; gap: 8px; margin-top: 12px; }
.ucg-file, .ucg-tree-node { display: flex; justify-content: space-between; gap: 10px; padding: 10px 12px; border-radius: 12px; background: #fff; border: 1px solid #dbeafe; }
.ucg-chart-bars { display: flex; align-items: end; gap: 12px; height: 180px; padding: 16px; border-radius: 16px; background: #f8fafc; }
.ucg-bar { flex: 1; min-width: 28px; border-radius: 10px 10px 0 0; background: linear-gradient(180deg, #60a5fa, #2563eb); display: flex; align-items: end; justify-content: center; color: #fff; font-size: 12px; font-weight: 900; padding-bottom: 6px; }
.ucg-alert { border-radius: 16px; padding: 14px 16px; background: #fff7ed; border: 1px solid #fed7aa; color: #9a3412; }
.ucg-result { display: grid; place-items: center; text-align: center; gap: 8px; min-height: 180px; }
.ucg-panel { border: 1px solid #dbeafe; border-radius: 18px; background: #f8fbff; padding: 18px; }
.ucg-message { position: sticky; bottom: 16px; justify-self: start; padding: 10px 14px; border-radius: 12px; background: #0f172a; color: #fff; box-shadow: 0 12px 30px rgba(15,23,42,.25); }
@media (max-width: 1100px) {
  .ucg-grid, .ucg-form, .ucg-descriptions { grid-template-columns: 1fr 1fr; }
}
</style>
