<template>
  <section class="page">
    <header class="page-header">
      <div>
        <p class="eyebrow">INBOUND ORDER MANAGEMENT</p>
        <h2>入库单列表页</h2>
        <p>用于查看、筛选和处理仓储入库单。</p>
      </div>
      <RouterLink class="primary-link" to="/inbound/orders/create">新建入库单</RouterLink>
    </header>

    <div class="stats-grid">
      <article>
        <span>待审核</span>
        <strong>{{ pendingCount }}</strong>
      </article>
      <article>
        <span>今日入库</span>
        <strong>{{ todayCount }}</strong>
      </article>
      <article>
        <span>异常单据</span>
        <strong>{{ exceptionCount }}</strong>
      </article>
    </div>

    <section class="card">
      <div class="toolbar">
        <input v-model="keyword" placeholder="搜索单号、供应商、仓库" />
        <button @click="loadOrders">刷新数据</button>
      </div>

      <p v-if="apiMessage" class="hint">{{ apiMessage }}</p>

      <table>
        <thead>
          <tr>
            <th>入库单号</th>
            <th>供应商</th>
            <th>仓库</th>
            <th>状态</th>
            <th>数量</th>
            <th>预计到货</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in filteredRows" :key="item.id">
            <td>{{ item.code }}</td>
            <td>{{ item.supplier }}</td>
            <td>{{ item.warehouse }}</td>
            <td><span class="tag">{{ item.status }}</span></td>
            <td>{{ item.quantity }}</td>
            <td>{{ item.expectedArrival }}</td>
            <td>
              <RouterLink to="/inbound/orders/detail">详情</RouterLink>
            </td>
          </tr>
        </tbody>
      </table>
    </section>
  </section>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'

const keyword = ref('')
const apiMessage = ref('')

const fallbackRows = [
  { id: 'IN-20260806-001', code: 'IN-20260806-001', supplier: '华东供应链有限公司', warehouse: '上海主仓', status: '待审核', quantity: 120, expectedArrival: '2026-08-06 16:00' },
  { id: 'IN-20260806-002', code: 'IN-20260806-002', supplier: '智能制造配件厂', warehouse: '苏州备件仓', status: '已提交', quantity: 80, expectedArrival: '2026-08-07 09:30' },
  { id: 'IN-20260806-003', code: 'IN-20260806-003', supplier: '北区运输服务部', warehouse: '北京中心仓', status: '异常待处理', quantity: 36, expectedArrival: '2026-08-07 14:20' },
]

const rows = ref(fallbackRows)

const filteredRows = computed(() => {
  const q = keyword.value.trim().toLowerCase()
  if (!q) return rows.value
  return rows.value.filter((item) => {
    return [item.code, item.supplier, item.warehouse, item.status].some((value) =>
      String(value).toLowerCase().includes(q),
    )
  })
})

const pendingCount = computed(() => rows.value.filter((item) => item.status.includes('待')).length)
const todayCount = computed(() => rows.value.length)
const exceptionCount = computed(() => rows.value.filter((item) => item.status.includes('异常')).length)

async function loadOrders() {
  apiMessage.value = ''
  try {
    const response = await fetch('/api/inbound/orders')
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`)
    }
    const payload = await response.json()
    const items = payload?.data?.items || payload?.data || payload?.items || []
    if (Array.isArray(items) && items.length) {
      rows.value = items
      apiMessage.value = '已从后端接口加载入库单数据。'
    } else {
      rows.value = fallbackRows
      apiMessage.value = '后端接口返回为空，当前展示内置示例数据。'
    }
  } catch (error) {
    rows.value = fallbackRows
    apiMessage.value = `接口暂不可用，当前展示本地示例数据：${error.message}`
  }
}

onMounted(loadOrders)
</script>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: 22px;
}

.page-header,
.card,
.stats-grid article {
  background: #fff;
  border: 1px solid #dbe5f5;
  border-radius: 18px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.06);
}

.page-header {
  padding: 26px 28px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.eyebrow {
  color: #2563eb;
  font-weight: 700;
  letter-spacing: 0.08em;
  margin: 0 0 8px;
}

h2 {
  margin: 0 0 10px;
  font-size: 28px;
}

p {
  margin: 0;
  color: #475569;
}

.primary-link,
button {
  border: 0;
  background: #2563eb;
  color: #fff;
  border-radius: 10px;
  padding: 10px 16px;
  text-decoration: none;
  cursor: pointer;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 16px;
}

.stats-grid article {
  padding: 18px 20px;
}

.stats-grid span {
  display: block;
  color: #64748b;
  margin-bottom: 8px;
}

.stats-grid strong {
  font-size: 28px;
}

.card {
  padding: 22px;
}

.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

input {
  flex: 1;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  padding: 10px 12px;
}

.hint {
  margin: 0 0 12px;
  color: #2563eb;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  text-align: left;
  padding: 13px 10px;
  border-bottom: 1px solid #e5e7eb;
}

th {
  color: #475569;
  font-size: 13px;
}

.tag {
  display: inline-block;
  background: #eff6ff;
  color: #1d4ed8;
  border-radius: 999px;
  padding: 4px 10px;
}
</style>
