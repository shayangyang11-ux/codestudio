<template>
  <section class="page">
    <header class="page-header">
      <p class="eyebrow">GENERATED NODE.JS PAGE</p>
      <h2>入库单详情页</h2>
      <p>用于查看入库单主信息、明细、状态流转和关联操作。</p>
    </header>

    <section class="card">
      <h3>入库单详情页</h3>
      <p>当前页面已接入 Vue Router 和运行预览。后续 Development Agent 会继续补充真实表单、接口、权限和数据联动。</p>
      <RouterLink to="/inbound/orders">返回入库单列表页</RouterLink>
    </section>
  </section>
</template>

<script setup>
</script>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: 22px;
}

.page-header,
.card {
  background: #fff;
  border: 1px solid #dbe5f5;
  border-radius: 18px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.06);
  padding: 26px 28px;
}

.eyebrow {
  color: #2563eb;
  font-weight: 700;
  letter-spacing: 0.08em;
  margin: 0 0 8px;
}

h2 {
  margin: 0 0 10px;
  font-size: 28px;
}

h3 {
  margin-top: 0;
}

p {
  color: #475569;
}

a {
  display: inline-block;
  margin-top: 16px;
  color: #2563eb;
  text-decoration: none;
  font-weight: 700;
}
</style>
