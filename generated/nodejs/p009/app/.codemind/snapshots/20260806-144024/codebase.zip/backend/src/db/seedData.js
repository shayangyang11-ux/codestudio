export const seedData = {
  "inbound_order_list_page": [
    {
      "id": "inbound_order_list_page-001",
      "createdAt": "2026-08-11 09:30:00"
    },
    {
      "id": "inbound_order_list_page-002",
      "createdAt": "2026-08-12 09:30:00"
    },
    {
      "id": "inbound_order_list_page-003",
      "createdAt": "2026-08-13 09:30:00"
    }
  ],
  "inbound_order_create_page": [
    {
      "id": "inbound_order_create_page-001",
      "createdAt": "2026-08-11 09:30:00"
    },
    {
      "id": "inbound_order_create_page-002",
      "createdAt": "2026-08-12 09:30:00"
    },
    {
      "id": "inbound_order_create_page-003",
      "createdAt": "2026-08-13 09:30:00"
    }
  ],
  "inbound_order_approval_page": [
    {
      "id": "inbound_order_approval_page-001",
      "createdAt": "2026-08-11 09:30:00"
    },
    {
      "id": "inbound_order_approval_page-002",
      "createdAt": "2026-08-12 09:30:00"
    },
    {
      "id": "inbound_order_approval_page-003",
      "createdAt": "2026-08-13 09:30:00"
    }
  ],
  "inbound_order_quantity_edit_page": [
    {
      "id": "inbound_order_quantity_edit_page-001",
      "createdAt": "2026-08-11 09:30:00"
    },
    {
      "id": "inbound_order_quantity_edit_page-002",
      "createdAt": "2026-08-12 09:30:00"
    },
    {
      "id": "inbound_order_quantity_edit_page-003",
      "createdAt": "2026-08-13 09:30:00"
    }
  ],
  "inbound_order_detail_page": [
    {
      "id": "inbound_order_detail_page-001",
      "createdAt": "2026-08-11 09:30:00"
    },
    {
      "id": "inbound_order_detail_page-002",
      "createdAt": "2026-08-12 09:30:00"
    },
    {
      "id": "inbound_order_detail_page-003",
      "createdAt": "2026-08-13 09:30:00"
    }
  ]
}
