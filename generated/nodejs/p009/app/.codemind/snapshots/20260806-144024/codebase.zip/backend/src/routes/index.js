import express from 'express'

const router = express.Router()

const orders = [
  { id: 'IN-20260806-001', code: 'IN-20260806-001', supplier: '华东供应链有限公司', warehouse: '上海主仓', status: '待审核', quantity: 120, expectedArrival: '2026-08-06 16:00' },
  { id: 'IN-20260806-002', code: 'IN-20260806-002', supplier: '智能制造配件厂', warehouse: '苏州备件仓', status: '已提交', quantity: 80, expectedArrival: '2026-08-07 09:30' },
  { id: 'IN-20260806-003', code: 'IN-20260806-003', supplier: '北区运输服务部', warehouse: '北京中心仓', status: '异常待处理', quantity: 36, expectedArrival: '2026-08-07 14:20' },
]

function ok(response, data, message = 'OK') {
  return response.json({
    success: true,
    code: 0,
    message,
    data,
  })
}

router.get('/health', (request, response) => {
  ok(response, {
    service: 'codemind-generated-backend',
    status: 'UP',
    generatedAt: new Date().toISOString(),
  })
})

router.get('/inbound/orders', (request, response) => {
  ok(response, {
    items: orders,
    total: orders.length,
    pageNo: 1,
    pageSize: 20,
  })
})

router.get('/inbound-order-list-page', (request, response) => {
  ok(response, {
    items: orders,
    total: orders.length,
    pageNo: 1,
    pageSize: 20,
  })
})

export function registerGeneratedRoutes(app) {
  app.get('/health', (request, response) => {
    ok(response, {
      service: 'codemind-generated-backend',
      status: 'UP',
      generatedAt: new Date().toISOString(),
    })
  })

  app.get('/api/health', (request, response) => {
    ok(response, {
      service: 'codemind-generated-backend',
      status: 'UP',
      generatedAt: new Date().toISOString(),
    })
  })

  app.use('/api', router)
  return app
}

export default router
