import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/', redirect: '/inbound/orders' },
  {
    path: '/inbound/orders',
    name: 'InboundOrderListPage',
    component: () => import('../modules/generated/pages/InboundOrderListPage.vue'),
  },
  {
    path: '/inbound-order-list-page',
    redirect: '/inbound/orders',
  },
  {
    path: '/inbound/orders/create',
    name: 'InboundOrderCreatePage',
    component: () => import('../modules/generated/pages/InboundOrderCreatePage.vue'),
  },
  {
    path: '/inbound-order-create-page',
    redirect: '/inbound/orders/create',
  },
  {
    path: '/inbound/orders/approval',
    name: 'InboundOrderApprovalPage',
    component: () => import('../modules/generated/pages/InboundOrderApprovalPage.vue'),
  },
  {
    path: '/inbound-order-approval-page',
    redirect: '/inbound/orders/approval',
  },
  {
    path: '/inbound/orders/quantity-edit',
    name: 'InboundOrderQuantityEditPage',
    component: () => import('../modules/generated/pages/InboundOrderQuantityEditPage.vue'),
  },
  {
    path: '/inbound-order-quantity-edit-page',
    redirect: '/inbound/orders/quantity-edit',
  },
  {
    path: '/inbound/orders/detail',
    name: 'InboundOrderDetailPage',
    component: () => import('../modules/generated/pages/InboundOrderDetailPage.vue'),
  },
  {
    path: '/inbound-order-detail-page',
    redirect: '/inbound/orders/detail',
  },
  { path: '/:pathMatch(.*)*', redirect: '/inbound/orders' },
]

export const generatedRoutes = routes
export const navigationRoutes = routes.filter((route) => route.name)

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export { router }
export default router
