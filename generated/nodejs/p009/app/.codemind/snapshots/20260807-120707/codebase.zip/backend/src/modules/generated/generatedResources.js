export const generatedResources = [
  {
    "resourceKey": "inbound_order_create_page",
    "apiSegment": "inbound-orders",
    "title": "入库单创建页",
    "pageKey": "inbound_order_create_page",
    "routePath": "/inbound/orders/create",
    "description": "由 Development Build Context 生成的业务资源。",
    "pageKind": "GENERIC",
    "surfaceType": "ACTION_ROUTE_PAGE",
    "navigationVisible": true,
    "entryMode": "NAVIGATION",
    "fields": [
      {
        "key": "id",
        "label": "ID",
        "type": "TEXT",
        "required": false
      }
    ],
    "seedRecords": [
      {
        "id": "inbound_order_create_page-001",
        "createdAt": "2026-08-11 09:30:00"
      },
      {
        "id": "inbound_order_create_page-002",
        "createdAt": "2026-08-12 09:30:00"
      },
      {
        "id": "inbound_order_create_page-003",
        "createdAt": "2026-08-13 09:30:00"
      }
    ]
  }
]
